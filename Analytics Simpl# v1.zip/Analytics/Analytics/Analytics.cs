﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Crestron.SimplSharp.CrestronXml;
using Crestron.SimplSharp.CrestronXmlLinq;
using Crestron.SimplSharp;                          				        // For Basic SIMPL# Classes
using Crestron.SimplSharp.CrestronLogger;
using Crestron.SimplSharp.CrestronIO;
using Crestron.SimplSharp.Scheduler;

namespace Analytics_Analysis
{
    #region Delegates
    public delegate void DelegateFn(ushort lt_first_standard_deviation, ushort lt_second_standard_deviation, ushort lt_third_standard_deviation, ushort lt_fourth_standard_deviation,
                                    ushort gt_first_standard_deviation, ushort gt_second_standard_deviation, ushort gt_third_standard_deviation, ushort gt_fourth_standard_deviation);
    public delegate void DelegateFn1(SimplSharpString Status);
    public delegate void DelegateFn2();
    #endregion

    public class Analytics
    {
        #region Delegates
        public DelegateFn callback_fn { get; set; }
        public DelegateFn1 callback_fn1 { get; set; }
        public DelegateFn2 callback_fn2 { get; set; }
        #endregion

        #region Declarations
        #region enums
        private enum Special_Analysis { None, Day_Based, Weekday_Based, Sunrise_Sunset };//special anaysis for calculations
		public enum Atro_Event_Type { NA, Sunrise, Sunset };
		private enum Occupancy_Type { Do_Not_Use, Use_Ignore_Data_In_Segment, Use_Fill_Data_In_Segment };
        #endregion

        #region Constants
        const int Hours_Per_Day = 24;
        const int Days_Per_Week = 7;
        DateTime Time_Marker = DateTime.Parse("2000-01-01");                    //marker for type 4 collection
        #endregion
        
        //Trigger Count Data for Analysis
        List<Trigger_Data>[] Saved_Trigger_Data;
        int Data_Count = 0;                                                     //number of usable elements in Saved_Trigger_Data based on special_analysis 

        //Holder for X & Y values data before it gets 
        //transferred to saved_trigger_data array 
        double Current_X_Data = 0;
        double Current_Y_Data = 0;

        //Holder for Type 4 current event data
        DateTime Current_Start;


        //Holder for number of occupants so trigger
        //data can be normalized to a single occupant
        double Number_Of_Occupants = 1;
        Occupancy_Type Use_Occupancy;											//false if number of occupants should be ignored
		DateTime Unoccupied_Start_Time;											//time when occupancy count drops to zero
		double Cumulative_Unoccupied_Time = 0;									//cumulative occupancy time during the segment in minutes
		bool Space_Unoccupied = false;											//true if space was unoccupied during collection cycle

        //Elements for Saving Init Parameters 
		string File_Path;
        int Data_Elements_Count;
        int Minimum_Elements_Before_Reporting;                                  //The number of data elements that need to be collected before reporting back to simpl
        int Analytic_Type;                                                      //1 = Count Triggers in a time period (Activity Count Tracking)
                                                                                //2 = Sample Analog Value on a Timed Interval (Inside Temperature During Winter)
                                                                                //3 = Time length of an Event vs. Correlated Data (Furnace Run Time vs. Outside Temp)
                                                                                //4 = Cumulative Time of an Activity during a time periond (time in bed in a day)

        //statistical calculationed values
        struct Statistics
        {
            public double Mean_Y;                                               //Mean of Y Data Elements
            public double Mean_X;                                               //Mean of X Data Elements
            public double Standard_Deviation;
            public double m;                                                    //Slope of line in Y = mX + b
            public double y_intercept;                                          //Y intercept of line in Y = mX + b
            public double r;                                                    //Covariance
        }
        Statistics[] Stats;

        //timer
		Atro_Event_Type Astro_Event;											//Holder for Event info
		long Delay_Between_Calculations;                                        //delay in msec
        long Delay_Before_Starting_Calculations;                                //delay in msec
        CTimer Timer = null;                                                    //timer thread for running analytics
        bool Timer_Running = false;                                             //true if cTimer is running, otherwise false
        Special_Analysis Special_Instructions;

        //Misc. Declarations
		BuiltInScheduler myScheduler;											//Create Scheduler for Sunrise/Sunset Events
		string Latitude;														//Latitude for sunrise, sunset events
		string Longitude;														//Longitude for sunrise, sunset events
		int Instance_ID;                                                        //Unique Identifier of Module
        int Group_Count = 1;                                                    //number of groups based on Special_Instructions
        CMutex mutex = new CMutex();                                            //mutex to guard type 4 collection
        bool Initialization_Complete = false;                                   //true after initialization has run
        bool Start_Saving_Data = false;                                         //can't start saving data until we have completed
                                                                                //one cycle since first cycle is only part of the time
                                                                                //of a cycle
        #endregion

        //****************************************************************************************
        // 
        //  Calculate_Statistical_Data	-	Default Constructor 
        // 
        //****************************************************************************************
        public Analytics()
        {
        }

        //****************************************************************************************
        // 
        //  Init	-	Read Data File and Initialize Operation 
        // 
        //****************************************************************************************
        public void Init(string filename, string path, int logger_level, int data_count, int Analytic_Type, 
            int Use_Occupancy, int Minimum_Elements_Before_Reporting, int Time_Between_Calcs, int Instance_ID,
			string Latitude, string Longitude)
        {
            #region Setup Logging
            //setup logging
            if (logger_level != 0)
            {
                try
                {
                    CrestronLogger.Initialize((uint)logger_level);
                }
                catch (Exception e)
                {
                    Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - LoggerError - " + e + "\n"));
                }
            }
            #endregion

            #region Save Parameters
            File_Path = String.Format("\\{2}\\{0}\\{1}", InitialParametersClass.ProgramIDTag, filename, path);
            Data_Elements_Count = data_count;
            this.Analytic_Type = Analytic_Type;
            this.Instance_ID = Instance_ID;
            this.Minimum_Elements_Before_Reporting = Minimum_Elements_Before_Reporting;
            if (Use_Occupancy == 0)
            {
                this.Use_Occupancy = Occupancy_Type.Do_Not_Use;
            }
            else if (Use_Occupancy == 1)
            {
                this.Use_Occupancy = Occupancy_Type.Use_Ignore_Data_In_Segment;
            }
			else if (Use_Occupancy == 2)
			{
				this.Use_Occupancy = Occupancy_Type.Use_Fill_Data_In_Segment;
			}
			else
			{
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Init - Illegal Use Occupancy Value\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Init - Illegal Use Occupancy Value\n", 0);
                this.Use_Occupancy = Occupancy_Type.Do_Not_Use;
			}
            //setup timer to turn calculations as new data is collected
            Delay_Between_Calculations = this.Time_Between_Calcs(Time_Between_Calcs) * 60000;
			//save lat/long for sunrise/sunset events
			this.Latitude = Latitude;
			this.Longitude = Longitude;
            #endregion

            #region Allocate Memory for Data Storage
            try
            {
                #region Create List Array
                if (Special_Instructions == Special_Analysis.Day_Based)
                {
					CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Init - Special Instructions - Day Based\n", 7);
					Saved_Trigger_Data = new List<Trigger_Data>[Hours_Per_Day];
                    for (int i = 0; i < Hours_Per_Day; i++)
                    {
                        Saved_Trigger_Data[i] = new List<Trigger_Data>();
                    }
                }
                else if (Special_Instructions == Special_Analysis.Weekday_Based)
                {
					CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Init - Special Instructions - WeekDay Based\n", 7);
					Saved_Trigger_Data = new List<Trigger_Data>[Days_Per_Week];
                    for (int i = 0; i < Days_Per_Week; i++)
                    {
                        Saved_Trigger_Data[i] = new List<Trigger_Data>();
                    }
                }
				else if (Special_Instructions == Special_Analysis.Sunrise_Sunset)
				{
					CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Init - Special Instructions - Sunrise/Sunset\n", 7);
					Saved_Trigger_Data = new List<Trigger_Data>[2];
					for (int i = 0; i < 2; i++)
					{
						Saved_Trigger_Data[i] = new List<Trigger_Data>();
					}
				}
				else
                {
					CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Init - Special Instructions - None\n", 7);
					Saved_Trigger_Data = new List<Trigger_Data>[1];
                    Saved_Trigger_Data[0] = new List<Trigger_Data>();
                }
                #endregion

                #region Group Statistics Storage
                Stats = new Statistics[1];
                if (Special_Instructions == Special_Analysis.Day_Based)
                {
                    Stats = new Statistics[Hours_Per_Day];
                }
                else if (Special_Instructions == Special_Analysis.Weekday_Based)
                {
                    Stats = new Statistics[Days_Per_Week];
                }
				else if (Special_Instructions == Special_Analysis.Sunrise_Sunset)
				{
					Stats = new Statistics[2];
				}
				else
                {
                    Stats = new Statistics[1];
                }
                #endregion
            }
            catch (Exception e)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Init - " + e + "\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Init - " + e + "\n", 0);
                Initialization_Complete = false;
                return;
            }
            #endregion

            #region Initialize Globals
            Current_X_Data = 0;
            Current_Y_Data = 0;
            #endregion

            #region Read XML
            //read data from xml file
            try
            {
                if (Read_XML_Data() == false)
                {
                    CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Init - Problem reading XML Data, Initialization Aborted\n"), 7);
                    return;                                                     //don't start timer thread if there was an issue reading the data file
                }
            }
            catch (Exception e)
            {
                CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Init -  Read_XML_Data - " + e + "\n"), 0);
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Init - Read_XML_Data - " + e + "\n"));
            }
            #endregion

            #region Calculate Analytics
            CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Init - Calculate Analytics\n"), 7);
            Calculate_Analytics();
            #endregion

            #region Initalize Occupancy
            if ((Number_Of_Occupants == 0) && (this.Use_Occupancy == Occupancy_Type.Use_Ignore_Data_In_Segment))
            {
                CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Init - Space Not Occupied\n"), 7);
                Space_Unoccupied = true;
            }
			else if ((Number_Of_Occupants == 0) && (this.Use_Occupancy == Occupancy_Type.Use_Fill_Data_In_Segment))
			{
				CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Init - Space Not Occupied\n"), 7);
				Unoccupied_Start_Time = DateTime.Now;							//save start date/time when house became unoccupied
				Space_Unoccupied = true;
			}
			else
			{
				CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Init - Space Occupied\n"), 7);
				Space_Unoccupied = false;
			}
            #endregion

            Initialization_Complete = true;
            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Init - Initialization Complete\n", 7);
        }

		//****************************************************************************************
        // 
        //  Start_Type_1_Collection	-	Start type 1 data collection and timed analytics
        // 
        //****************************************************************************************
        public void Start_Type_1_Collection()
        {
            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Start_Type_1_Collection - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 1)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_1_Collection - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Start_Type_1_Collection - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            #region Start Data Collection
			if (Special_Instructions == Special_Analysis.Sunrise_Sunset)
			{
				Init_Sunrise_Sunset_Events();
			}
			else if (Delay_Between_Calculations == 0)
            {
                CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_1_Collection - Can't create timer with 0 delay\n"), 0);
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_1_Collection - Can't create timer with 0 delay\n"));
                return;
            }
            else
            {
                //start the analytics system main worker thread
				Delay_Before_Starting_Calculations = Calculate_Timer_Start_Delay(Delay_Between_Calculations / 60000);
				if (Timer == null)
                {
                    try
                    {
                        CTimerCallbackFunction cTimerCallbackFunction = new CTimerCallbackFunction(Type_1_Timer_Thread);
						Timer = new CTimer(Type_1_Timer_Thread, null, Delay_Before_Starting_Calculations, Delay_Between_Calculations);
                        Timer_Running = true;
                    }
                    catch (Exception e)
                    {
                        CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_1_Collection - Can't create timer thread - " + e + "\n"), 0);
                        Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_1_Collection - Can't create timer thread - " + e + "\n"));
                    }
                }
                else if (Timer_Running == false)                                //don't try and restart the timer if it is already running
                {
                    try
                    {
                        //restart timer that was previously stopped
                        CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_1_Collection - Restarting Timer\n"), 7);
						Timer.Reset(Delay_Before_Starting_Calculations, Delay_Between_Calculations);
                        Timer_Running = true;
                    }
                    catch (Exception e)
                    {
                        CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_1_Collection - Can't restart timer thread - " + e + "\n"), 0);
                        Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_1_Collection - Can't restart timer thread - " + e + "\n"));
                    }
                }
            }
            #endregion
        }

        //****************************************************************************************
        // 
        //  Type_1_Timer_Thread	-	run analytics on timed basis for Count 
        //                          Triggers in a time period (Activity Count Tracking)
        // 
        //****************************************************************************************
        private void Type_1_Timer_Thread(Object obj)
        {

            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Timer_Thread\n", 7);

            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Timer_Thread - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            //until one cycle has passed we won't have collected a full cycle's data
            //and that will skew analysis so skip
            if (Start_Saving_Data == true)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Timer_Thread - Data Valid\n", 7);
				
				//if ajustment option selected and space was unoccupied for part of the cycle, adjust data
				if ((Use_Occupancy == Occupancy_Type.Use_Fill_Data_In_Segment) && ((Cumulative_Unoccupied_Time != 0) || (Space_Unoccupied == true)))
				{
					Adjust_Data_Based_On_Occupancy();
				}
				//Perform Analytics
				if ((Space_Unoccupied == false) || ((Space_Unoccupied == true) && (Use_Occupancy == Occupancy_Type.Use_Fill_Data_In_Segment)))
                {
                    #region Compare new Data to Previously Calculated Standard Deviation
                    Check_New_Data_vs_SD();
                    #endregion

                    #region Save Current Data to List
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Timer_Thread - Data Valid - Saving to List\n", 7);
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Timer_Thread - Current_X_Data = " + Current_X_Data + "\n", 7);
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Timer_Thread - Current_Y_Data = " + Current_Y_Data + "\n", 7);

                    int Group_Index = Get_Group_Index();

                    //if we have max amount of data, remove oldest before adding new
                    if (Saved_Trigger_Data[Group_Index].Count == Data_Elements_Count)
                    {
                        Saved_Trigger_Data[Group_Index].RemoveAt(0);
                        CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Timer_Thread - more data in xml file than space for in items array.  Truncating reading\n", 7);
                    }

                    //add new data to list
                    Saved_Trigger_Data[Group_Index].Add(new Trigger_Data(Current_X_Data, Current_Y_Data, DateTime.Now));
                    #endregion

                    #region Save Array to File
                    Save_XML_Data();
                    #endregion

                    #region Calculate Analytics
                    Calculate_Analytics();
                    #endregion
                }
                else
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Timer_Thread - Space Unoccupied During Cycle.  Event Data Igonored\n", 7);
                }
            }
            else
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Timer_Thread - No Valid Data - Setting Flag for Next Cycle\n", 7);
                Start_Saving_Data = true;
            }

            #region Initialize storage and flags for next cycle
			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Timer_Thread - Clearing Current X-Y Data\n", 7);
			Current_X_Data = 0;
            Current_Y_Data = 0;
            //if house is now occupied, reset the unoccupied flag so we can use the next cycle's data
            //unless the space becomes unoccupied again
            if (Number_Of_Occupants != 0)
            {
                Space_Unoccupied = false;
            }
            #endregion
        }

        //****************************************************************************************
        // 
        //  Type_1_Event_Trigger	-	Pulse to add to count of input being statistically tracked
        // 
        //****************************************************************************************
        public void Type_1_Event_Trigger(int Increment_Value)
        {
            #region Local Declarations
            double Normalized_Increment_Value;
            #endregion

            #region Validate Initialization Done and One Cycle of Data Complete
            //can't process trigger until initialization is complete 
            //or until we are going to collect a full cycle of data collection
            if ((Initialization_Complete == false) || (Start_Saving_Data == false))
            {
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 1)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Type_1_Event_Trigger - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Event_Trigger - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            #region Normalize new data for number of occupants
            if (Number_Of_Occupants != 0)
            {
                Normalized_Increment_Value = Convert.ToDouble(Increment_Value) / Number_Of_Occupants;
            }
            else
            {
                Normalized_Increment_Value = 0;
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_1_Event_Trigger - Number_Of_Occupants=0. House Unoccupied\n. Event Ignored", 7);
            }
            #endregion

            #region Increment Current Trigger Count
            Current_Y_Data += Normalized_Increment_Value;
            #endregion
        }

        //****************************************************************************************
        // 
        //  Start_Type_2_Collection	-	Start type 2 data collection and timed analytics
        // 
        //****************************************************************************************
        public void Start_Type_2_Collection()
        {
            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Start_Type_2_Collection - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 2)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_2_Collection - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Start_Type_2_Collection - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            #region Request Y Data
            callback_fn2();
            #endregion

            #region Start Data Collection
			if (Special_Instructions == Special_Analysis.Sunrise_Sunset)
			{
				Init_Sunrise_Sunset_Events();
			}
			else if (Delay_Between_Calculations == 0)
            {
                CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_2_Collection - Can't create timer with 0 delay\n"), 0);
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_2_Collection - Can't create timer with 0 delay\n"));
                return;
            }
            else
            {
                //start the analytics system main worker thread
				Delay_Before_Starting_Calculations = Calculate_Timer_Start_Delay(Delay_Between_Calculations / 60000);
				if (Timer == null)
                {
                    try
                    {
                        CTimerCallbackFunction cTimerCallbackFunction = new CTimerCallbackFunction(Type_2_Timer_Thread);
						Timer = new CTimer(Type_2_Timer_Thread, null, Delay_Before_Starting_Calculations, Delay_Between_Calculations);
                        Timer_Running = true;
                    }
                    catch (Exception e)
                    {
                        CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_2_Collection - Can't create timer thread - " + e + "\n"), 0);
                        Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_2_Collection - Can't create timer thread - " + e + "\n"));
                    }
                }
                else if (Timer_Running == false)                                //don't try and restart the timer if it is already running
                {
                    try
                    {
                        //restart timer that was previously stopped
                        CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_2_Collection - Restarting Timer\n"), 7);
						Timer.Reset(Delay_Before_Starting_Calculations, Delay_Between_Calculations);
                        Timer_Running = true;
                    }
                    catch (Exception e)
                    {
                        CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_2_Collection - Can't restart timer thread - " + e + "\n"), 0);
                        Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_2_Collection - Can't restart timer thread - " + e + "\n"));
                    }
                }
            }
            #endregion
        }

        //****************************************************************************************
        // 
        //  Type_2_Timer_Thread	-	run analytics on timed basis for analog value
        //                          in a time period - Sample Analog Value on a Timed 
        //                          Interval (Inside Temperature During Winter)
        // 
        //****************************************************************************************
        private void Type_2_Timer_Thread(Object obj)
        {
            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_2_Timer_Thread\n", 7);

            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_2_Timer_Thread - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            //until one cycle has passed we won't have collected a full cycle's data
            //and that will skew analysis so skip
            if (Start_Saving_Data == true)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_2_Timer_Thread - Data Valid\n", 7);

				//Perform Analytics
				if ((Space_Unoccupied == false) || ((Space_Unoccupied == true) && (Use_Occupancy == Occupancy_Type.Use_Fill_Data_In_Segment)))
                {
                    #region Compare new Data to Previously Calculated Standard Deviation
                    Check_New_Data_vs_SD();
                    #endregion

                    #region Save Current Data to List
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_2_Timer_Thread - Data Valid - Saving to List\n", 7);
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_2_Timer_Thread - Current_X_Data = " + Current_X_Data + "\n", 7);
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_2_Timer_Thread - Current_Y_Data = " + Current_Y_Data + "\n", 7);

                    int Group_Index = Get_Group_Index();

                    //if we have max amount of data, remove oldest before adding new
                    if (Saved_Trigger_Data[Group_Index].Count == Data_Elements_Count)
                    {
                        Saved_Trigger_Data[Group_Index].RemoveAt(0);
                        CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_2_Timer_Thread - more data in xml file than space for in items array.  Truncating reading\n", 7);
                    }

                    //add new data to list
                    Saved_Trigger_Data[Group_Index].Add(new Trigger_Data(Current_X_Data, Current_Y_Data, DateTime.Now));
                    #endregion

                    #region Save Array to File
                    Save_XML_Data();
                    #endregion

                    #region Calculate Analytics
                    Calculate_Analytics();
                    #endregion
                }
                else
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_2_Timer_Thread - Space Unoccupied During Cycle.  Event Data Igonored\n", 7);
                }
            }
            else
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_2_Timer_Thread - No Valid Data - Setting Flag for Next Cycle\n", 7);
                Start_Saving_Data = true;
            }

            #region Initialize flags for next cycle
            //if house is now occupied, reset the unoccupied flag so we can use the next cycle's data
            //unless the space becomes unoccupied again
            if (Number_Of_Occupants != 0)
            {
                Space_Unoccupied = false;
            }
            #endregion
        }

        //****************************************************************************************
        // 
        //  Type_2_Y_Value	-	Call to save current y analog value
        // 
        //****************************************************************************************
        public void Type_2_Y_Value(int Y)
        {
            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_2_Y_Value - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 2)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Type_2_Y_Value - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_2_Y_Value - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            #region Save Current Y Value
            Current_Y_Data = Y;
            #endregion
        }

        //****************************************************************************************
        // 
        //  Start_Type_3_Collection	-	Start type 3 data collection
        // 
        //****************************************************************************************
        public void Start_Type_3_Collection()
        {
            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Start_Type_3_Collection - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 3)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_3_Collection - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Start_Type_3_Collection - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            #region Request Y Data
            callback_fn2();
            #endregion

            #region Start Data Collection
            Current_X_Data = 0;
            Current_Y_Data = 0;
            Current_Start = Time_Marker;
            #endregion
        }

        //****************************************************************************************
        // 
        //  Type_3_X_Value	-	Call to save current x analog value
        // 
        //****************************************************************************************
        public void Type_3_X_Value(int X)
        {
            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_X_Value - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 3)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Type_3_X_Value - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_X_Value - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            #region Save Current X Value
            Current_X_Data = X;
            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_X_Value - Saving X Value = " + X + "\n", 7);
            #endregion
        }

        //****************************************************************************************
        // 
        //  Type_3_X_Diff	-	Call to save differnce between 2 analog inputs 
        //                      as the x value
        // 
        //****************************************************************************************
        public void Type_3_X_Diff(int x1, int x2)
        {
            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_X_Value - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 3)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Type_3_X_Value - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_X_Value - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            #region Save Current X Value
            Current_X_Data = Math.Abs(x1 - x2);
            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_X_Diff - Saving X Difference, x1 = " + x1 + ", x2 = " + x2 + ", difference = " + Current_X_Data + "\n", 7);
            #endregion
        }

        //****************************************************************************************
        // 
        //  Type_3_Event_Start	-	 Capture start time of type 3 event
        // 
        //****************************************************************************************
        public void Type_3_Event_Start()
        {
            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_Event_Stop - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 3)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Type_3_Event_Start - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_Event_Start - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            Current_Start = DateTime.Now;
        }

        //****************************************************************************************
        // 
        //  Type_3_Event_Stop	-	 type 3 event stop
        // 
        //****************************************************************************************
        public void Type_3_Event_Stop()
        {
            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_Event_Stop - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 3)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Type_3_Event_Stop - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_Event_Stop - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            #region Validate Start Event Captured
            if (Current_Start == Time_Marker)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_Event_Stop - No Valid Start Event.  Event Data Ignored\n", 7);
                return;
            }
            #endregion

            #region Capture End of Event Information
            Current_Y_Data = ((DateTime.Now - Current_Start).TotalSeconds);
            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_Event_Stop - Event Time = " + Current_Y_Data + " seconds\n", 7);
            #endregion

			//until one cycle has passed we won't have collected a full cycle's data
			//and that will skew analysis so skip
			if (Start_Saving_Data == true)
			{
				#region Compare new Data to Previously Calculated Standard Deviation
                Check_New_Data_vs_SD();
                #endregion

                #region Save Current Data to List
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_Event_Stop - Data Valid - Saving to List\n", 7);
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_Event_Stop - Current_X_Data = " + Current_X_Data + "\n", 7);
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_Event_Stop - Current_Y_Data = " + Current_Y_Data + "\n", 7);

                int Group_Index = Get_Group_Index();

                //if we have max amount of data, remove oldest before adding new
                if (Saved_Trigger_Data[Group_Index].Count == Data_Elements_Count)
                {
                    Saved_Trigger_Data[Group_Index].RemoveAt(0);
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_Event_Stop - more data in xml file than space for in items array.  Truncating reading\n", 7);
                }

                //add new data to list
                Saved_Trigger_Data[Group_Index].Add(new Trigger_Data(Current_X_Data, Current_Y_Data, DateTime.Now));
                #endregion

                #region Save Array to File
                Save_XML_Data();
                #endregion

                #region Calculate Analytics
                Calculate_Analytics();
                #endregion
            }
            else
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_3_Event_Stop - No Valid Data - Setting Flag for Next Cycle\n", 7);
                Start_Saving_Data = true;
            }

            #region Initialize storage
            Current_Y_Data = 0;
            Current_Start = Time_Marker;
            #endregion
        }

        //****************************************************************************************
        // 
        //  Start_Type_4_Collection	-	Start type 4 data collection and timed analytics
        // 
        //****************************************************************************************
        public void Start_Type_4_Collection()
        {
            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Start_Type_4_Collection - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 4)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_4_Collection - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Start_Type_4_Collection - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            #region Start Data Collection
			if (Special_Instructions == Special_Analysis.Sunrise_Sunset)
			{
				Init_Sunrise_Sunset_Events();
			}
			else if (Delay_Between_Calculations == 0)
            {
                CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_4_Collection - Can't create timer with 0 delay\n"), 0);
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_4_Collection - Can't create timer with 0 delay\n"));
                return;
            }
            else
            {
                //start the analytics system main worker thread
				Delay_Before_Starting_Calculations = Calculate_Timer_Start_Delay(Delay_Between_Calculations / 60000);
				if (Timer == null)
                {
                    try
                    {
                        CTimerCallbackFunction cTimerCallbackFunction = new CTimerCallbackFunction(Type_4_Timer_Thread);
						Timer = new CTimer(Type_4_Timer_Thread, null, Delay_Before_Starting_Calculations, Delay_Between_Calculations);
                        Timer_Running = true;
                    }
                    catch (Exception e)
                    {
                        CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_4_Collection - Can't create timer thread - " + e + "\n"), 0);
                        Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_4_Collection - Can't create timer thread - " + e + "\n"));
                    }
                }
                else if (Timer_Running == false)                                //don't try and restart the timer if it is already running
                {
                    try
                    {
                        //restart timer that was previously stopped
                        CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_4_Collection - Restarting Timer\n"), 7);
						Timer.Reset(Delay_Before_Starting_Calculations, Delay_Between_Calculations);
                        Timer_Running = true;
                    }
                    catch (Exception e)
                    {
                        CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_4_Collection - Can't restart timer thread - " + e + "\n"), 0);
                        Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Start_Type_4_Collection - Can't restart timer thread - " + e + "\n"));
                    }
                }
            }
            #endregion
        }

        //****************************************************************************************
        // 
        //  Type_4_Timer_Thread	-	run analytics on timed basis for 
        //                          Cumulative Time of an Activity during 
        //                          a time periond (time in bed in a day)
        // 
        //****************************************************************************************
        private void Type_4_Timer_Thread(Object obj)
        {

            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Timer_Thread\n", 7);

            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Timer_Thread - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            //don't execute until other access to data elements are finished
            mutex.WaitForMutex();

            //until one cycle has passed we won't have collected a full cycle's data
            //and that will skew analysis so skip
            if (Start_Saving_Data == true)
            {
				//if ajustment option selected and space was unoccupied for part of the cycle, adjust data
				if ((Use_Occupancy == Occupancy_Type.Use_Fill_Data_In_Segment) && ((Cumulative_Unoccupied_Time != 0) || (Space_Unoccupied == true)))
				{
					Adjust_Data_Based_On_Occupancy();
				}
				//Perform Analytics
				if ((Space_Unoccupied == false) || ((Space_Unoccupied == true) && (Use_Occupancy == Occupancy_Type.Use_Fill_Data_In_Segment)))
				{
					#region Compare new Data to Previously Calculated Standard Deviation
                    Check_New_Data_vs_SD();
                    #endregion

                    #region Save Current Data to List
                    //manage situation where Type 4 timer is still running
                    if (Current_Start != Time_Marker)
                    {
                        CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Timer_Thread - Timer still running, capturing data\n", 7);
                        //Capture the time that has expired and reset start for next timer thread cycle
                        Current_Y_Data += ((DateTime.Now - Current_Start).TotalSeconds);
                    }
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Timer_Thread - Data Valid - Saving to List\n", 7);
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Timer_Thread - Current_X_Data = " + Current_X_Data + "\n", 7);
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Timer_Thread - Current_Y_Data = " + Current_Y_Data + " Seconds\n", 7);

                    int Group_Index = Get_Group_Index();

                    //if we have max amount of data, remove oldest before adding new
                    if (Saved_Trigger_Data[Group_Index].Count == Data_Elements_Count)
                    {
                        Saved_Trigger_Data[Group_Index].RemoveAt(0);
                        CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Timer_Thread - more data in xml file than space for in items array.  Truncating reading\n", 7);
                    }

                    //add new data to list
                    Saved_Trigger_Data[Group_Index].Add(new Trigger_Data(Current_X_Data, Current_Y_Data, DateTime.Now));
                    #endregion

                    #region Save Array to File
                    Save_XML_Data();
                    #endregion

                    #region Calculate Analytics
                    Calculate_Analytics();
                    #endregion
                }
                else
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Timer_Thread - Space Unoccupied During Cycle.  Event Data Igonored\n", 7);
                }
            }
            else
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Timer_Thread - No Valid Data - Setting Flag for Next Cycle\n", 7);
                Start_Saving_Data = true;
            }

            #region Initialize storage and flags for next cycle
            Current_X_Data = 0;
            Current_Y_Data = 0;
            //if timer was still running then restart it for next measurement cycle
            if (Current_Start != Time_Marker)
            {
                Current_Start = DateTime.Now;
            }

            //if house is now occupied, reset the unoccupied flag so we can use the next cycle's data
            //unless the space becomes unoccupied again
            if (Number_Of_Occupants != 0)
            {
                Space_Unoccupied = false;
            }
            #endregion

            mutex.ReleaseMutex();
        }

        //****************************************************************************************
        // 
        //  Type_4_Event_Start	-	 Capture start time of type 4 event
        // 
        //****************************************************************************************
        public void Type_4_Event_Start()
        {
            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Event_Start - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 4)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Type_4_Event_Start - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Event_Start - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            mutex.WaitForMutex();
            Current_Start = DateTime.Now;
            mutex.ReleaseMutex();
        }

        //****************************************************************************************
        // 
        //  Type_4_Event_Stop	-	 type 4 event stop
        // 
        //****************************************************************************************
        public void Type_4_Event_Stop()
        {
            #region Validate Initialization Done
            //can't process data until initialization is complete
            if (Initialization_Complete == false)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Event_Start - Initialization Not Complete, aborting\n", 7);
                return;
            }
            #endregion

            #region Check Analytic Type
            if (Analytic_Type != 4)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Type_4_Event_Stop - Call for Wrong Analytic Type\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Event_Stop - Call for Wrong Analytic Type\n", 0);
                return;
            }
            #endregion

            mutex.WaitForMutex();

            #region Validate Start Event Captured
            if (Current_Start == Time_Marker)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Event_Stop - No Valid Start Event.  Event Data Ignored\n", 7);
                mutex.ReleaseMutex();
                return;
            }
            #endregion

            #region Capture Time Length of Event
            double temp = ((DateTime.Now - Current_Start).TotalSeconds);
            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Type_4_Event_Stop - Event Time = " + temp + " seconds\n", 7);
            Current_Y_Data += temp;
            Current_Start = Time_Marker;
            #endregion

            mutex.ReleaseMutex();
        }

        //****************************************************************************************
        // 
        //  Calculate_Analytics	-   Analytic Calculations
        // 
        //****************************************************************************************
        private void Calculate_Analytics()
        {
            #region Local Declarations
            double a, b, c, d, e, f;
            double temp1, temp2;
            int i;
            double sum_of_x_values;
            double Cov, Sx, Sy;
            #endregion

            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Data Element Count = " + Data_Count + "\n", 7);
			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group Count = " + Group_Count + "\n", 7);
			CrestronConsole.PrintLine("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group Count = " + Group_Count + "\n", 7);//tester

            for (int Group_Index = 0; Group_Index < Group_Count; Group_Index++)
            {
                #region Initalize Local Variables
                a = 0;
                b = 0;
                c = 0;
                d = 0;
                e = 0;
                f = 0;
                Stats[Group_Index].m = 0;
                #endregion

                #region Sum Data Elements and Count Them
                Stats[Group_Index].Mean_Y = 0;
                Stats[Group_Index].Mean_X = 0;
                Data_Count = 0;
                foreach (Trigger_Data t in Saved_Trigger_Data[Group_Index])
                {
                    Stats[Group_Index].Mean_Y += t.Y;
                    Stats[Group_Index].Mean_X += t.X;
                    Data_Count++;
                }
                #endregion

                //need at least 2 data elements to calculate analytical data
                if (Data_Count < 2)
                {
                    return;
                }

                #region Calculate Mean
                Stats[Group_Index].Mean_Y /= Data_Count;
                Stats[Group_Index].Mean_X /= Data_Count;
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - Mean_Y = " + Math.Round(Stats[Group_Index].Mean_Y, 2) + "\n", 7);
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - Mean_X = " + Math.Round(Stats[Group_Index].Mean_X, 2) + "\n", 7);
                #endregion

                #region Calculate Variance and Variance Squared
                foreach (Trigger_Data t in Saved_Trigger_Data[Group_Index])
                {
                    t.Temp = t.Y - Stats[Group_Index].Mean_Y;
                    t.Temp = t.Temp * t.Temp;
                }
                #endregion

                #region Calculate Standard Deviation
                Stats[Group_Index].Standard_Deviation = 0;
                foreach (Trigger_Data t in Saved_Trigger_Data[Group_Index])
                {
                    Stats[Group_Index].Standard_Deviation += t.Temp;
                }
                Stats[Group_Index].Standard_Deviation /= (Data_Count - 1);
                Stats[Group_Index].Standard_Deviation = Math.Sqrt(Stats[Group_Index].Standard_Deviation);
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - Standard_Deviation = " + Math.Round(Stats[Group_Index].Standard_Deviation, 2) + "\n", 7);
                #endregion

                #region Calculate Trendline
                //Calculations Based On http://classroom.synonym.com/calculate-trendline-2709.html

                #region calculate slope of trendline
                #region calculate a
                i = 1;
                foreach (Trigger_Data t in Saved_Trigger_Data[Group_Index])
                {
                    a += t.Y * i;
                    i++;
                }
                a *= Data_Count;
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - a = " + Math.Round(a, 2) + "\n", 7);
                #endregion

                #region calculate b
                temp1 = 0;
                temp2 = 0;
                i = 1;
                foreach (Trigger_Data t in Saved_Trigger_Data[Group_Index])
                {
                    temp1 += t.Y;
                    temp2 += i;

                    i++;
                }
                b = temp1 * temp2;
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - b = " + Math.Round(b, 2) + "\n", 7);
                #endregion

                #region calculate c
                i = 1;
                foreach (Trigger_Data t in Saved_Trigger_Data[Group_Index])
                {
                    c += (i * i);

                    i++;
                }
                c *= Data_Count;
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - c = " + Math.Round(c, 2) + "\n", 7);
                #endregion

                #region calculate d & e
                i = 1;
                foreach (Trigger_Data t in Saved_Trigger_Data[Group_Index])
                {
                    d += i;
                    e += t.Y;
                    i++;
                }
                sum_of_x_values = d;
                d *= d;
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - d = " + Math.Round(d, 2) + "\n", 7);
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - e = " + Math.Round(e, 2) + "\n", 7);
                #endregion

                #region calculate slope m
                Stats[Group_Index].m = (a - b) / (c - d);
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + 
                    " - Slope m = " + Math.Round(Stats[Group_Index].m, 2) + "\n", 7);
                #endregion
                #endregion

                #region calculate the y intercept of the trendline

                #region calculate f
                f = Stats[Group_Index].m * sum_of_x_values;
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - f = " + Math.Round(f, 2) + "\n", 7);
                #endregion

                #region calculate y intercept
                Stats[Group_Index].y_intercept = (e - f) / Data_Count;
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + 
                    " - y-intercept = " + Math.Round(Stats[Group_Index].y_intercept, 2) + "\n", 7);
                #endregion
                #endregion
                #endregion

                #region Pass Data Back To Simpl
                callback_fn1("Mean: " + Math.Round(Stats[Group_Index].Mean_Y, 2));
                callback_fn1("Standard Deviation: " + Math.Round(Stats[Group_Index].Standard_Deviation, 2));
                callback_fn1("Trendline: y = " + Math.Round(Stats[Group_Index].m, 2) + "x + " + Math.Round(Stats[Group_Index].y_intercept, 2));
                #endregion

                //Calculate Correlation Coeficient for correlated data
                // Based On - http://sphweb.bumc.bu.edu/otlt/MPH-Modules/BS/BS704_Multivariable/BS704_Multivariable5.html
                #region Calculate Correlation Coeficient
                if (Analytic_Type == 3)
                {
                    #region Calculate X Variance
                    Sx = 0;
                    foreach (Trigger_Data t in Saved_Trigger_Data[Group_Index])
                    {
                        Sx += ((t.X - Stats[Group_Index].Mean_X) * (t.X - Stats[Group_Index].Mean_X));
                    }
                    Sx /= (Data_Count - 1);
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - Sx = " + Math.Round(Sx, 2) + "\n", 7);
                    #endregion

                    #region Calculate Y Variance
                    Sy = 0;
                    foreach (Trigger_Data t in Saved_Trigger_Data[Group_Index])
                    {
                        Sy += ((t.Y - Stats[Group_Index].Mean_Y) * (t.Y - Stats[Group_Index].Mean_Y));
                    }
                    Sy /= (Data_Count - 1);
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - Sy = " + Math.Round(Sy, 2) + "\n", 7);
                    #endregion

                    #region Calculate Covariance
                    Cov = 0;
                    foreach (Trigger_Data t in Saved_Trigger_Data[Group_Index])
                    {
                        Cov += ((t.X - Stats[Group_Index].Mean_X) * (t.Y - Stats[Group_Index].Mean_Y));
                    }
                    Cov /= (Data_Count - 1);
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - Covariance = " + Math.Round(Cov, 2) + "\n", 7);
                    #endregion

                    #region Calculate r
                    if ((Cov == 0) && ((Sx == 0) || (Sy == 0)))
                    {
                        Stats[Group_Index].r = 1;
                    }
                    else if ((Sx == 0) || (Sy == 0))
                    {
                        Stats[Group_Index].r = 1;
                    }
                    else
                    {
                        Stats[Group_Index].r = Cov / (Math.Sqrt(Sx * Sy));
                    }
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Group " + Group_Index + " - r = " + Math.Round(Stats[Group_Index].r, 2) + "\n", 7);
                    #endregion 

                    #region Pass Data Back To Simpl
                    callback_fn1("Correlation Coeficient: r = " + Math.Round(Stats[Group_Index].r, 2));
                    if (Math.Abs(Stats[Group_Index].r) >= .7)
                    {
                        callback_fn1("Group " + Group_Index + " - Correlation Coeficient Shows a Strong Linear Relationship");
                    }
                    else if (Math.Abs(Stats[Group_Index].r) >= .3)
                    {
                        callback_fn1("Group " + Group_Index + " - Correlation Coeficient Shows a Moderate Linear Relationship");
                    }
                    else if (Math.Abs(Stats[Group_Index].r) > 0)
                    {
                        callback_fn1("Group " + Group_Index + " - Correlation Coeficient Shows a Weak Linear Relationship");
                    }
                    else
                    {
                        callback_fn1("Group " + Group_Index + " - Correlation Coeficient Shows No Linear Relationship");
                    }
                    #endregion
                }
                #endregion
            }

            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Calculate_Analytics - Calculations Complete\n", 7);
        }

        //****************************************************************************************
        // 
        //  Check_New_Data_vs_SD	-   Check newly collected data vs. standard deviation
        // 
        //****************************************************************************************
        private void Check_New_Data_vs_SD()
        {
            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD\n", 7);

            //Get index based on Special Instructions
            int Group_Index = Get_Group_Index();    

            if (Data_Count < Minimum_Elements_Before_Reporting)
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Not Enough Data Elements Saved For Error Matching\n", 7);
                return;
            }

            double Difference = Math.Abs(Stats[Group_Index].Mean_Y - Current_Y_Data);
            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Mean = " + Stats[Group_Index].Mean_Y + "\n", 7);
            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Standard Deviation = " + Stats[Group_Index].Standard_Deviation + "\n", 7);
            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Difference from Mean = " + Difference + "\n", 7);

            if (Difference > (Stats[Group_Index].Standard_Deviation * 4))
            {
                if (Current_Y_Data < Stats[Group_Index].Mean_Y)
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Greater Than 4 Standard Deviations\n", 7);
                    callback_fn((ushort)1, (ushort)1, (ushort)1, (ushort)1, (ushort)0, (ushort)0, (ushort)0, (ushort)0);
                }
                else
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Less Than 4 Standard Deviations\n", 7);
                    callback_fn((ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)1, (ushort)1, (ushort)1, (ushort)1);
                }
            }
            else if (Difference > (Stats[Group_Index].Standard_Deviation * 3))
            {
                if (Current_Y_Data < Stats[Group_Index].Mean_Y)
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Greater Than 3 Standard Deviations\n", 7);
                    callback_fn((ushort)1, (ushort)1, (ushort)1, (ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)0);
                }
                else
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Less Than 3 Standard Deviations\n", 7);
                    callback_fn((ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)1, (ushort)1, (ushort)1, (ushort)0);
                }
            }
            else if (Difference > (Stats[Group_Index].Standard_Deviation * 2))
            {
                if (Current_Y_Data < Stats[Group_Index].Mean_Y)
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Greater Than 2 Standard Deviations\n", 7);
                    callback_fn((ushort)1, (ushort)1, (ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)0);
                }
                else
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Less Than 2 Standard Deviations\n", 7);
                    callback_fn((ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)1, (ushort)1, (ushort)0, (ushort)0);
                }
            }
            else if (Difference > Stats[Group_Index].Standard_Deviation)
            {
                if (Current_Y_Data < Stats[Group_Index].Mean_Y)
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Greater Than 1 Standard Deviations\n", 7);
                    callback_fn((ushort)1, (ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)0);
                }
                else
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Less Than 1 Standard Deviations\n", 7);
                    callback_fn((ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)1, (ushort)0, (ushort)0, (ushort)0);
                }
            }
            else
            {
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Check_New_Data_vs_SD - Within One Standard Deviation\n", 7);
                callback_fn((ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)0, (ushort)0);
            }
        }

        //****************************************************************************************
        // 
        //  Read_XML_Data	-	Read XML Data from File
        // 
        //****************************************************************************************
        private bool Read_XML_Data()
        {
            #region Local Declarations
            double X, Y;
            DateTime Date_Time;
            int Analytic_Type;
            string Special_Instructions;
            #endregion

            try
            {
                #region Clear Data
                for (int i = 0; i < Group_Count; i++)
                {
                    Saved_Trigger_Data[i].Clear();
                }
                #endregion

                #region Check if File Exists
                //Check if the File Exists
                if (!Crestron.SimplSharp.CrestronIO.File.Exists(File_Path))
                {
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - XML Data File Not Found - " + File_Path + "\n", 7);
                    return (true);
                }
                #endregion

                #region Open XML File
                //open xml file
                XDocument doc;
                FileStream fs = new FileStream(File_Path, FileMode.Open, FileAccess.Read);
                XmlReader xr = new XmlReader(fs);
                xr.MoveToContent();
                doc = XDocument.Load(xr);
                #endregion

                #region Read Trigger Data
                #region Read General Information
                //Find root element for GeneralInformation
                XElement generalElement = doc
                    .Element("TriggerInformation")
                    .Element("GeneralInformation");

                Analytic_Type = Convert.ToInt32(generalElement.Element("Analytic_Type").Value);
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - Analytic_Type = " + Analytic_Type + "\n", 7);
                if (Analytic_Type != this.Analytic_Type)
                {
                    Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Read_XML_Data - XML File Analytic Type Does Not Match Module Analytic Type\n"));
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - XML File Analytic Type Does Not Match Module Analytic Type\n", 0);
                    xr.Close();
                    fs.Close();
                    return false;
                }

                Special_Instructions = generalElement.Element("Special_Instructions").Value;
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - Special_Instructions = " + Special_Instructions + "\n", 7);
                if (Special_Instructions != Special_Analysis_To_String(this.Special_Instructions))
                {
                    Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Read_XML_Data - XML File Special_Instructions Does Not Match Module Special_Instructions\n"));
                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - XML File Special_Instructions Does Not Match Module Special_Instructions\n", 0);
                    xr.Close();
                    fs.Close();
                    return false;
                }
                #endregion

                #region Read Groups
                XElement root_groups = doc
                    .Element("TriggerInformation")
                    .Element("Groups");
                //count the number of groups
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - group_count = " + root_groups.Elements().Count() + "\n", 7);

                if (root_groups.Elements().Count() > 0)
                {
                    int group_index = 0;
                    IEnumerable<XElement> groups = root_groups.Elements();
                    foreach (XElement group in groups)							//loop through xml elements
                    {
                        #region Read Items
       					//Find root element for data for each item in the group
    					XElement root_items = group.Element("Items");

                        //count the number of items
                        CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - item_count = " + root_items.Elements().Count() + "\n", 7);

                        if (root_items.Elements().Count() > 0)
                        {
                            IEnumerable<XElement> items = root_items.Elements();
                            foreach (XElement item in items)							//loop through xml elements
                            {
                                //make sure xml file doesn't contain more elements than we want.
                                //if so, we need to remove the first(which is the oldest) item in 
                                //the list before adding a new item
                                if (Saved_Trigger_Data[group_index].Count == Data_Elements_Count)
                                {
                                    Saved_Trigger_Data[group_index].RemoveAt(0);
                                    CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data- more data in xml file than space for in items array.  Truncating reading\n", 7);
                                }

                                //read data elements from xml file and add them to the list
                                X = Convert.ToDouble(item.Element("X").Value);
                                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - X = " + X + "\n", 7);

                                //read data elements from xml file and add them to the list
                                Y = Convert.ToDouble(item.Element("Y").Value);
                                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - Y = " + Y + "\n", 7);

                                Date_Time = Convert.ToDateTime(item.Element("DateTime").Value);
                                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - Date_Time = " + Date_Time + "\n", 7);

                                Saved_Trigger_Data[group_index].Add(new Trigger_Data(X, Y, Date_Time));
                            }
                        }
                        #endregion
                        group_index++;
                    }
                }
                #endregion
                #endregion

                #region Close Filestream and Reader
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - Reading Done, Closing Filestream & Reader\n", 7);
                xr.Close();
                fs.Close();
                #endregion

                return true;
            }
            catch (Exception e)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Read_XML_Data - " + e + "\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Read_XML_Data - " + e + "\n", 0);
                return false;
            }
        }

        //****************************************************************************************
        // 
        //  Save_XML_Data	-	Nightly Save of Data to File
        // 
        //****************************************************************************************
        private void Save_XML_Data()
        {
            #region Validate Initialization Done
            //can't process trigger until initialization is complete
            if (Initialization_Complete == false)
            {
                return;
            }
            #endregion

            try
            {
                #region Write XML File
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Save_XML_Data - Saving File\n", 7);
                using (var writer = new XmlTextWriter(File_Path, Encoding.UTF8))
                {
                    writer.Formatting = Formatting.Indented;

                    writer.WriteStartDocument();

                    #region Write General Information
                    writer.WriteStartElement("TriggerInformation");
                    writer.WriteStartElement("GeneralInformation");

                    writer.WriteStartElement("Analytic_Type");
                    writer.WriteString(Analytic_Type.ToString());
                    writer.WriteEndElement();//Analytic_Type

                    writer.WriteStartElement("Special_Instructions");
                    writer.WriteString(Special_Analysis_To_String(Special_Instructions));
                    writer.WriteEndElement();//Special_Instructions

                    writer.WriteEndElement();//GeneralInformation
                    #endregion

                    #region Write Group Data
                    writer.WriteStartElement("Groups");

                    for (int i = 0; i < Group_Count; i++)
                    {
                        writer.WriteStartElement("Group");
                        #region Write Item Data
                        writer.WriteStartElement("Items");

                        foreach (Trigger_Data t in Saved_Trigger_Data[i])
                        {
                            writer.WriteStartElement("Item");

                            writer.WriteStartElement("X");
                            writer.WriteString(t.X.ToString());
                            writer.WriteEndElement();//X

                            writer.WriteStartElement("Y");
                            writer.WriteString(t.Y.ToString());
                            writer.WriteEndElement();//Y

                            writer.WriteStartElement("DateTime");
                            writer.WriteString(t.Date_Time.ToString());
                            writer.WriteEndElement();//DateTime

                            writer.WriteEndElement();//Item
                        }
                        writer.WriteEndElement();//Items
                        #endregion
                        writer.WriteEndElement();//Group
                    }

                    writer.WriteEndElement();//Groups
                    #endregion //Groups

                    writer.WriteEndElement();//TriggerInformation

                    writer.WriteEndDocument();
                    writer.Close();
                }
                #endregion
            }
            catch (Exception e)
            {
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Save_XML_Data - " + e + "\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Save_XML_Data - " + e + "\n", 0);
            }
        }

        //****************************************************************************************
        // 
        //  Set_Number_Of_Occupants	-	Sets number of people occupying space so trigger can be
        //                              normalized to a single occupant
        // 
        //****************************************************************************************
        public void Set_Number_Of_Occupants(int Number_Of_Occupants)
        {
            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Set_Number_Of_Occupants - Occupancy Set to " + Number_Of_Occupants + "\n", 7);
            this.Number_Of_Occupants = Convert.ToDouble(Number_Of_Occupants);

            //when the number of occupants drops to zero during a measurement cycle
            //save the the space was unoccupied so the data won't be used.
            if ((Number_Of_Occupants == 0) && (Use_Occupancy == Occupancy_Type.Use_Ignore_Data_In_Segment) && (Space_Unoccupied == false))
			{
                Space_Unoccupied = true;
			}
            else if ((Number_Of_Occupants == 0) && (Use_Occupancy == Occupancy_Type.Use_Fill_Data_In_Segment) && (Space_Unoccupied == false))
            {
				Unoccupied_Start_Time = DateTime.Now;							//save start date/time when house became unoccupied
                Space_Unoccupied = true;
            }
			else if ((Number_Of_Occupants != 0) && (Use_Occupancy == Occupancy_Type.Use_Fill_Data_In_Segment) && (Space_Unoccupied == true))
			{
				Space_Unoccupied = false;
				Cumulative_Unoccupied_Time += (DateTime.Now - Unoccupied_Start_Time).Minutes;
			}
        }
		//****************************************************************************************
		// 
		//  Adjust_Data_Based_On_Occupancy	-	Adjust collected data based on time space was
		//										occupied
		// 
		//****************************************************************************************
		private void Adjust_Data_Based_On_Occupancy()
		{
			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Adjust_Data_Based_On_Occupancy\n", 7);

			//Get index based on Special Instructions
			int Group_Index = Get_Group_Index();
			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Adjust_Data_Based_On_Occupancy - Group Index = " + Group_Index + "\n", 7);

			//if we are unoccupied then update cumulatie unoccupied time for the end of this cycle
			//and reset unoccupied start time for the next cycle
			if (Space_Unoccupied == true)
			{
				Cumulative_Unoccupied_Time += (DateTime.Now - Unoccupied_Start_Time).Minutes;
				Unoccupied_Start_Time = DateTime.Now;
			}
	
			//Calculate percentage of time during cycle that the space wasn't occupied
			double Unoccupied_Percentage = Cumulative_Unoccupied_Time / (Delay_Between_Calculations / 60000);
			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Adjust_Data_Based_On_Occupancy - Cumulative_Unoccupied_Time = " + Cumulative_Unoccupied_Time + "\n", 7);
			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Adjust_Data_Based_On_Occupancy - Delay_Between_Calculations = " + Delay_Between_Calculations /60000 + "\n", 7);
			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Adjust_Data_Based_On_Occupancy - Unoccupied_Percentage = " + Unoccupied_Percentage + "\n", 7);
					
			if (Unoccupied_Percentage >= .9)									//unoccupied 90%, or more, use average since data won't be reliable
			{
				Current_Y_Data = Stats[Group_Index].Mean_Y;
				CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Adjust_Data_Based_On_Occupancy - New Current_Y_Data = Mean = " + Current_Y_Data + "\n", 7);
			}
			else
			{
				Current_Y_Data = Current_Y_Data / (1 - Unoccupied_Percentage);
				CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Adjust_Data_Based_On_Occupancy - New Current_Y_Data = " + Current_Y_Data + "\n", 7);
			}
			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Adjust_Data_Based_On_Occupancy - New Current_Y_Data = " + Current_Y_Data + "\n", 7);

			Cumulative_Unoccupied_Time = 0;
		}
        //****************************************************************************************
        // 
        //  Logger_Trigger_Data	-	Write Trigger Data to Logger
        // 
        //****************************************************************************************
        public void Logger_Trigger_Data()
        {
            #region Local Declarations
            int i, j;
            #endregion

            #region Validate Initialization Done
            //can't process trigger until initialization is complete
            if (Initialization_Complete == false)
            {
                return;
            }
            #endregion

            CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Logger_Trigger_Data - Dump\n", 0);

			#region Scheduled Events
			if (Special_Instructions == Special_Analysis.Sunrise_Sunset)
			{
				myScheduler.Dump_Scheduler_Event_Info();
			}
			#endregion

			#region Write Current Item Data
			CrestronLogger.WriteToLog("Current Item Data - \n", 0);
            CrestronLogger.WriteToLog("   Current_X_Data = " + Current_X_Data + "\n", 0);
            CrestronLogger.WriteToLog("   Current_Y_Data = " + Current_Y_Data + "\n", 0);
            CrestronLogger.WriteToLog("\n", 0);
            #endregion

            #region Write Saved Data
            for (i = 0; i < Group_Count; i++)
            {
                j = 0;
                CrestronLogger.WriteToLog("Saved Data - Group - " + i + "\n", 0);
                foreach (Trigger_Data t in Saved_Trigger_Data[i])
                {
                    CrestronLogger.WriteToLog("    Saved Data - " + j + "\n", 0);
                    CrestronLogger.WriteToLog("        X = " + t.X + "\n", 0);
                    CrestronLogger.WriteToLog("        Y = " + t.Y + "\n", 0);
                    CrestronLogger.WriteToLog("        Date_Time = " + t.Date_Time.ToString() + "\n\n", 0);
                    j++;
                }

                if (Saved_Trigger_Data[i].Count >= 2)
                {
                    CrestronLogger.WriteToLog("\n", 0);
                    CrestronLogger.WriteToLog("     Mean_X = " + Stats[i].Mean_X + "\n", 0);
                    CrestronLogger.WriteToLog("     Mean_Y = " + Stats[i].Mean_Y + "\n", 0);
                    CrestronLogger.WriteToLog("     Standard Deviation = " + Stats[i].Standard_Deviation + "\n", 0);
                    CrestronLogger.WriteToLog("     Trendline: y = " + Math.Round(Stats[i].m, 2) + "x + " + Math.Round(Stats[i].y_intercept, 2), 0);
                    if (Analytic_Type == 3)
                    {
                        CrestronLogger.WriteToLog("     r = " + Math.Round(Stats[i].r, 2) + "\n", 0);
                    }
                }
                CrestronLogger.WriteToLog("\n", 0);
            }
            CrestronLogger.WriteToLog("\n", 0);
            #endregion
        }

        //****************************************************************************************
        // 
        //  Time_Between_Calcs	-	Convets the parameter passed as 
        //                          time between calcs to minutes and
        //                          saves parameters based on special instructions
        // 
        //****************************************************************************************
        private int Time_Between_Calcs(int Time_Between_Calcs)
        {
            switch (Time_Between_Calcs)
            {
                case 1:                                                         //1 minute
                    Special_Instructions = Special_Analysis.None;
                    Group_Count = 1;
                    return 1;

                case 2:                                                         //5 minutes
                    Special_Instructions = Special_Analysis.None;
                    Group_Count = 1;
                    return 5;

                case 3:                                                         //15 minutes
                    Special_Instructions = Special_Analysis.None;
                    Group_Count = 1;
                    return 15;

                case 4:                                                         //30 minutes
                    Special_Instructions = Special_Analysis.None;
                    Group_Count = 1;
                    return 30;

                case 5:                                                         //1 hour
                    Special_Instructions = Special_Analysis.None;
                    Group_Count = 1;
                    return 60;

                case 6:                                                         //4 hours
                    Special_Instructions = Special_Analysis.None;
                    Group_Count = 1;
                    return 240;

                case 7:                                                         //8 hours
                    Special_Instructions = Special_Analysis.None;
                    Group_Count = 1;
                    return 480;

                case 8:                                                         //1 day
                    Special_Instructions = Special_Analysis.None;
                    Group_Count = 1;
                    return 1440;

                case 9:                                                         //hourly with day based analysis
                    Special_Instructions = Special_Analysis.Day_Based;
                    Group_Count = Hours_Per_Day;
                    return 60;

                case 10:                                                         //daily with day based analysis
                    Special_Instructions = Special_Analysis.Weekday_Based;
                    Group_Count = Days_Per_Week;
                    return 1440;

				case 11:                                                         //daily with day based analysis
					Special_Instructions = Special_Analysis.Sunrise_Sunset;
					Group_Count = 2;
					return 0;
				
				default:
                    CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Time_Between_Calcs - invalid parameter\n"), 0);
                    Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Time_Between_Calcs - invalid parameter\n"));
                    return 0;
            }
        }
        
        //****************************************************************************************
        // 
        //  Special_Analysis_To_String	-	Convets enum to string
        // 
        //****************************************************************************************
        private String Special_Analysis_To_String(Special_Analysis t)
        {
            if (t == Special_Analysis.Day_Based)
            {
                return ("Day_Based");
            }
            else if (t == Special_Analysis.Weekday_Based)
            {
                return ("Weekday_Based");
            }
			else if (t == Special_Analysis.Sunrise_Sunset)
			{
				return ("Sunrise_Sunset");
			}
			else
            {
                return ("None");
            }
        }

        //****************************************************************************************
        // 
        //  Get_Group_Index	-	Returns the current group index based on 
        //                      special instructions
        // 
        //****************************************************************************************
        private int Get_Group_Index()
        {
            if (Special_Instructions == Special_Analysis.Day_Based)
            {
                return (DateTime.Now.Hour);
            }
            else if (Special_Instructions == Special_Analysis.Weekday_Based)
            {
                return ((int)DateTime.Now.DayOfWeek);
            }
			else if (Special_Instructions == Special_Analysis.Sunrise_Sunset)
			{
				if (Astro_Event == Atro_Event_Type.Sunset)
				{
					return (0);													//Data collected during the day goes in first section of array
				}
				else if (Astro_Event == Atro_Event_Type.Sunrise)
				{
					return (1);													//Data collected at night goes in second section of array
				}
				else
				{
					//unknown event type
					Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Get_Group_Index - Invalid Astro Event Type\n"));
					CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Get_Group_Index - Invalid Astro Event Type\n", 0);
					return (0);
				}
			}
			else
            {
                return (0);
            }
        }

        //****************************************************************************************
        // 
        //  Calculate_Timer_Start_Delay	-	Calculate the ms delay required to start the
        //                                  timer for collecting data to align the timer
        //                                  with calender time
        // 
        //****************************************************************************************
        private long Calculate_Timer_Start_Delay(long Time_Between_Calcs)
        {
            DateTime start;
            double temp;
            TimeSpan span;
            DateTime now = DateTime.Now;

            switch (Time_Between_Calcs)
            {
                case 1:                                                         //1 minute
					CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Calculate_Timer_Start_Delay - Timer Start Time = Immediate Start\n"), 7);
					return (0);

                case 5:                                                         //5 minutes
                case 15:                                                        //15 minutes
                case 30:                                                        //30 minutes
                case 60:                                                        //1 hour
                case 240:                                                       //4 hours
                case 480:                                                       //8 hours
					start = DateTime.Today.AddDays(1);                          //Tomorrow
					span = start - now;                                         //Time between now and end of day
					temp = span.TotalMinutes % Time_Between_Calcs;				//Minutes between now and next  interval
					start = now.AddMinutes(temp);								//Calculate time to next 5 minute interval
					start = start.AddSeconds(-5);								//Subtract another 5 seconds so we are right at the end of an interval
					if (now > start)                                            //check if too late to start
					{
						start = start.AddMinutes(Time_Between_Calcs);           //goto next interval
					}
					span = start - now;                                         //get difference between start and now
					break;

                case 1440:                                                      //1 day or hourly with day based analysis or daily with day based analysis
                    start = DateTime.Today.AddDays(1);                          //Tomorrow
                    start.AddSeconds(-5);                                       //5 Seconds before midnight
                    if (now > start)                                            //check if too late to start today
                    {
                        start = start.AddDays(1);                               //wait one more day
                    }
                    span = start - now;                                         //get difference between start and now
					break;

                default:
                    CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Calculate_Timer_Start_Delay - invalid parameter\n"), 0);
                    Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Calculate_Timer_Start_Delay - invalid parameter\n"));
                    return 0;
            }
			CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Calculate_Timer_Start_Delay - Timer Start Time = " + start + "\n"), 7);
			return ((long)span.TotalMilliseconds);								//pass back milliseconds to delay before start
        }

		//****************************************************************************************
		// 
		//  Init_Sunrise_Sunset_Events - Initialize the scheduler and events
		// 
		//****************************************************************************************
		private void Init_Sunrise_Sunset_Events()
		{
			try
			{
				myScheduler = new BuiltInScheduler();
				myScheduler.Sunrise_Sunset_Event += new Sunrise_Sunset_Event_Handler(Sunrise_Sunset_Event);
				myScheduler.Initialize_Scheduler(Instance_ID, Latitude, Longitude);
			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("Analytics - Instance " + Instance_ID + " - Init_Sunrise_Sunset_Events - " + e + "\n"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Init_Sunrise_Sunset_Events - " + e + "\n"));
			}
		}

		//****************************************************************************************
		// 
		//  Sunrise_Sunset_Event - Event handler called from scheduler
		// 
		//****************************************************************************************
		public void Sunrise_Sunset_Event(ScheduledEvent SchEvent)
		{
			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Sunrise_Sunset_Event -" + SchEvent.Name + "\n", 7);
			
			//Fill Holder
			if (SchEvent.Name == "Sunrise")
			{
				Astro_Event = Atro_Event_Type.Sunrise;
			}
			else if (SchEvent.Name == "Sunset")
			{
				Astro_Event = Atro_Event_Type.Sunset;
			}
			else
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Sunrise_Sunset_Event - Invalid Astro Event - " + SchEvent.Name + "\n"));
				CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Sunrise_Sunset_Event - Invalid Astro Event - " + SchEvent.Name + "\n", 0);
				Astro_Event = Atro_Event_Type.NA;
				return;
			}

			//Call the correct handler code based on the Analytic Type
			switch (Analytic_Type)
			{
				case 1:
					Type_1_Timer_Thread(null);
					break;

				case 2:
					Type_2_Timer_Thread(null);
					break;

				case 3:
					Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Sunrise_Sunset_Event - Invalid Combination - Type 3 and Sunrise-Sunset\n"));
					CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Sunrise_Sunset_Event - Invalid Combination - Type 3 and Sunrise-Sunset\n", 0);
					break;

				case 4:
					Type_4_Timer_Thread(null);
					break;
			}
		}
	}
}
