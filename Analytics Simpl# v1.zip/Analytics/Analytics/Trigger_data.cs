﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;

namespace Analytics_Analysis
{
    public class Trigger_Data
    {
        public Trigger_Data()
        {
            this.X = 0;
            this.Y = 0;
            this.Temp = 0;
        }

        public Trigger_Data(double X, double Y, DateTime Date_Time)
        {
            this.X = X;
            this.Y = Y;
            this.Date_Time = Date_Time;
            this.Temp = 0;
        }

        #region Declarations
        public double X;
        public double Y;
        public DateTime Date_Time;                                              //date/time data was saved
        public double Temp;                                                     //used during analytics calculations
        #endregion
    }
}