﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Scheduler;
using Crestron.SimplSharp.CrestronLogger;


namespace Analytics_Analysis
{
	#region Delegates
	public delegate void Sunrise_Sunset_Event_Handler(ScheduledEvent SchEvent);
	#endregion

	public class BuiltInScheduler
	{
		#region Declarations
		ScheduledEventGroup myGroup;
		ScheduledEvent[] myEvent = new ScheduledEvent[2];

		public event Sunrise_Sunset_Event_Handler Sunrise_Sunset_Event;

		int Instance_ID;
		double Latitude;
		double Longitude;
		#endregion

		//****************************************************************************************
		// 
		//  BuiltInScheduler	-	Constructor
		// 
		//****************************************************************************************
		public BuiltInScheduler()
		{
			myGroup = new ScheduledEventGroup("Astro_Event_Group");
		}

		//****************************************************************************************
		// 
		//  Initialize_Scheduler	-	Create the events
		// 
		//****************************************************************************************
		public void Initialize_Scheduler(int Instance_ID, string Latitude, string Longitude)
		{
			DateTime Tomorrow = DateTime.Now.AddDays(1);
			ushort Trigger_Hour;
			ushort Trigger_Minute;

			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Initialize_Scheduler\n", 7);

            #region Save Parameters
			this.Instance_ID = Instance_ID;
			this.Latitude =  Convert.ToDouble(Latitude);
			this.Longitude =  Convert.ToDouble(Longitude);
			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Initialize_Scheduler - Latitude = " + Latitude + ", Longitude = " + Longitude + "\n", 7);
			#endregion

			#region Create Events
			try
			{
				myGroup.RetrieveAllEvents();

				if (myGroup.ScheduledEvents.ContainsKey("Sunrise") == false)
				{
					myEvent[0] = new ScheduledEvent("Sunrise", myGroup);
					myEvent[0].Description = "Sunrise Event";
					myEvent[0].Location.Latitude = this.Latitude;
					myEvent[0].Location.Longitude = this.Longitude;
					myEvent[0].DateAndTime.SetAstronomicalEventTime(
						ScheduledEventCommon.eAstronomicalEvent.Sunrise,
						Tomorrow.Year,
						Tomorrow.Month,
						Tomorrow.Day);
					myEvent[0].Acknowledgeable = true;
					myEvent[0].Persistent = false;
					myEvent[0].Recurrence.Daily();
					myEvent[0].AcknowledgeExpirationTimeout.Hour = 10;
					myEvent[0].UserCallBack += new ScheduledEvent.UserEventCallBack(Scheduler_UserCallBack);
					ScheduledEventCommon.CalculateAstronomicalTime(myEvent[0], out Trigger_Hour, out Trigger_Minute);
					CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Initialize_Scheduler - Sunrise Event " + 
						myEvent[0].Name + " " +  Trigger_Hour + ":" + Trigger_Minute + "\n", 0);
					myEvent[0].Enable();
					CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Initialize_Scheduler - Event:" + myEvent[0].Name + " Created\n", 7);
				}

				if (myGroup.ScheduledEvents.ContainsKey("Sunset") == false)
				{
					myEvent[1] = new ScheduledEvent("Sunset", myGroup);
					myEvent[1].Description = "Sunset Event";
					myEvent[1].Location.Latitude = this.Latitude;
					myEvent[1].Location.Longitude = this.Longitude;
					myEvent[1].DateAndTime.SetAstronomicalEventTime(
						ScheduledEventCommon.eAstronomicalEvent.Sunset,
						Tomorrow.Year,
						Tomorrow.Month,
						Tomorrow.Day);
					myEvent[1].Acknowledgeable = true;
					myEvent[1].Persistent = false;
					myEvent[1].Recurrence.Daily();
					myEvent[1].AcknowledgeExpirationTimeout.Hour = 10;
					myEvent[1].UserCallBack += new ScheduledEvent.UserEventCallBack(Scheduler_UserCallBack);
					ScheduledEventCommon.CalculateAstronomicalTime(myEvent[1], out Trigger_Hour, out Trigger_Minute);
					CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Initialize_Scheduler - Sunset Event " + 
						myEvent[1].Name + " " +  Trigger_Hour + ":" + Trigger_Minute + "\n", 0);
					myEvent[1].Enable();
					CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Initialize_Scheduler - Event:" + myEvent[1].Name + " Created\n", 7);
				}
			}
			catch (Exception e)
			{
                Crestron.SimplSharp.ErrorLog.Error(string.Format("Analytics - Instance " + Instance_ID + " - Initialize_Scheduler - " + e + "\n"));
                CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Initialize_Scheduler - " + e + "\n", 0);
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Scheduler_UserCallBack	-	Called when event occurs.  
		//								Call delegate and reschedule event for tomorrow
		// 
		//****************************************************************************************
		void Scheduler_UserCallBack(ScheduledEvent SchEvent, ScheduledEventCommon.eCallbackReason type)
		{
			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Scheduler_UserCallBack -" + SchEvent.Name + "\n", 7);
			CrestronConsole.PrintLine("Analytics - Instance " + Instance_ID + " - Scheduler_UserCallBack -" + SchEvent.Name + "\n", 7);//tester
			//Call delegate to act on scheduled event
			Sunrise_Sunset_Event(SchEvent);

			SchEvent.Acknowledge();
		}
		//****************************************************************************************
		// 
		//  Dump_Scheduler_Event_Info	-	Dumps scheduled event info to Logger
		// 
		//****************************************************************************************
		public void Dump_Scheduler_Event_Info()
		{
			ushort Trigger_Hour;
			ushort Trigger_Minute;

			CrestronLogger.WriteToLog("Analytics - Instance " + Instance_ID + " - Scheduled Events\n", 0);
			myGroup.RetrieveAllEvents();
			foreach (KeyValuePair<string, ScheduledEvent> kvp in myGroup.ScheduledEvents)
			{
				ScheduledEventCommon.CalculateAstronomicalTime(kvp.Value, out Trigger_Hour, out Trigger_Minute);
				CrestronLogger.WriteToLog("     Event: " + kvp.Value.Name + ", " + Trigger_Hour + ":" + Trigger_Minute + "\n", 0);
			}
			CrestronLogger.WriteToLog("\n", 0);
		}
	}
}