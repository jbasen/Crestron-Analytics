﻿using System.Reflection;

[assembly: AssemblyTitle("Analytics")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Analytics")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyVersion("1.0.0.*")]

